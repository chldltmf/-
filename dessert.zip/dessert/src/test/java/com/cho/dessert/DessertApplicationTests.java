package com.cho.dessert;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DessertApplicationTests {

	@Test
		void 더미데이터() {
			
		}

}
