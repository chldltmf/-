package com.cho.dessert.domain.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Goods extends BaseTimeEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long gno;
	
	private String name;
	private int price;//판매가
	private int sale;//할인
	private int stock;
	
	@Column(columnDefinition = "text",nullable = false)
	private String content;
	
	@Builder.Default
	@Enumerated(EnumType.STRING)
	//@CollectionTable(name = "colors")
	@ElementCollection
	private Set<Color> colors=new HashSet<>();
	
	@Builder.Default
	@Enumerated(EnumType.STRING)
	//@CollectionTable(name = "size")
	@ElementCollection
	private Set<Size> size=new HashSet<>();
	
	@Builder.Default
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="gno")
	List<GoodsFile> files=new ArrayList<>();
	
	public Goods addFile(GoodsFile file) {
		files.add(file);
		return this;
	}
	
	@Builder.Default
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinColumn
	private Set<Category> categorys=new HashSet<>();
	
	
	
	public Goods addCategory(Category category) {
		categorys.add(category);
		return this;
	}
}
