package com.cho.dessert.service;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.visual.VisualInsertDTO;

public interface VisualService {

	String save(MultipartFile vimg, VisualInsertDTO dto);

	String list(Model model);

	String indexList(Model model);

}
