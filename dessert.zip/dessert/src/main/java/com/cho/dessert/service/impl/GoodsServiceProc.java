package com.cho.dessert.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.goods.CategoryDTO;
import com.cho.dessert.domain.dto.goods.GoodsDetailDTO;
import com.cho.dessert.domain.dto.goods.GoodsInsertDTO;
import com.cho.dessert.domain.dto.goods.GoodsListDTO;
import com.cho.dessert.domain.entity.CategoryRepository;
import com.cho.dessert.domain.entity.Goods;
import com.cho.dessert.domain.entity.GoodsFile;
import com.cho.dessert.domain.entity.GoodsRepository;
import com.cho.dessert.service.GoodsService;

@Service
public class GoodsServiceProc implements GoodsService {

	@Autowired
	private GoodsRepository goodsRepository;
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	//파일업로드
	@Override
	public String tempFileupload(MultipartFile file) {
		String path="/images/goods/temp/";
		ClassPathResource cpr=new ClassPathResource("static"+path);
		
		try {
			File location=cpr.getFile();
			File targetFile=new File(location, file.getOriginalFilename());
			file.transferTo(targetFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return path+file.getOriginalFilename();
	}
	
	//상품등록
	@Override
	public String save(GoodsInsertDTO dto) {
		//서버에 있음
		String def=dto.getDefImgName();
		String add=dto.getAddImgName();
		String path="/images/goods/temp/";
		ClassPathResource cpr=new ClassPathResource("static"+path);
		
		Goods entity=dto.toEntity();
		
		try {
			File root=cpr.getFile();
			
			/////////////defFile////////////////////
			File defFile=new File(root,def);
			String name=defFile.getName();
			long size=defFile.length();
			defFile.renameTo(new File(root.getParent(),def));
			
			GoodsFile defGoodsFile=GoodsFile.builder()
					.orgName(name).newName(name).size(size).isDefImg(true).url("/images/goods/")
					.build();
			////////////addFile/////////////////////////
			File addFile=new File(root,add);
			name=addFile.getName();
			size=addFile.length();
			addFile.renameTo(new File(root.getParent(), add));
			
			GoodsFile addGoodsFile=GoodsFile.builder()
					.orgName(name).newName(name).size(size).isDefImg(false).url("/images/goods/")
					.build();
			
			goodsRepository.save(entity.addFile(defGoodsFile).addFile(addGoodsFile)
								.addCategory(categoryRepository.findById(dto.getCaNo()).get()));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return "redirect:goods";
	}

	//ajax를 통한 2차카테고리 목록 가져오기
	@Override
	public List<CategoryDTO> categoryList(long caNo) {
		return categoryRepository.findByCaNoBetween(caNo,caNo+99)
				.stream()
				.map(CategoryDTO::new)
				.toList();
	}

	

	//관리자페이지 -> 상품리스트페이지이동
	@Override
	public String list(Model model) {
		List<GoodsListDTO> result=goodsRepository.findAll()
				.stream()
				.map(GoodsListDTO::new)
				.toList();
		
		model.addAttribute("list",result);
		return "admin/goods/list";
	}

	//ajax 인덱스페이지 상품
	@Override
	public String indexList(Model model) {
		List<GoodsListDTO> result=goodsRepository.findAll().stream()
				.map(GoodsListDTO::new)
				.toList();
			
		model.addAttribute("list",result);
		return "admin/goods/listData";
	}
	
	//상품 상세페이지
	@Override
	public String detail(long gno, Model model) {
		model.addAttribute("detail",goodsRepository.findById(gno)
				.map(GoodsDetailDTO::new)
				.get());
		return "admin/goods/detail";
	}

	//카테고리 상위목록이동
	@Override
	public void goodsListByCategoryA(long caNo, Model model) {
		model.addAttribute("list",
									goodsRepository.findAllByCategorysCaNoBetween(caNo,caNo+99)
									.stream()
									.map(GoodsListDTO::new)
									.toList());
		
	}

	//카테고리 하위목록이동
	@Override
	public void goodsListByCaNo(long caNo, Model model) {
		model.addAttribute("list", 
				goodsRepository.findAllByCategorysCaNo(caNo).stream()
				.map(GoodsListDTO::new)
				.toList());
	}

	

}
