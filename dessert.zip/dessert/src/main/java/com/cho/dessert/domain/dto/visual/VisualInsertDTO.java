package com.cho.dessert.domain.dto.visual;

import com.cho.dessert.domain.dto.FileData;
import com.cho.dessert.domain.entity.VisualFile;

import lombok.Setter;

@Setter
public class VisualInsertDTO extends FileData{

	private String title;
	private String sub;
	private String link;
	private long num;
	
	public void addFileDate(FileData fileDate) {
		url=fileDate.getUrl();
		orgName=fileDate.getOrgName();
		size=fileDate.getSize();
	}

	public VisualFile toVisualFile() {
		return VisualFile.builder()
				.title(title).sub(sub).link(link).num(num)
				.url(url).orgName(orgName).size(size)
				.build();
	}
}
