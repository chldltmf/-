package com.cho.dessert.security;

import java.util.Map;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import com.cho.dessert.domain.entity.Member;
import com.cho.dessert.domain.entity.MemberRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class CustomOauth2UserService extends DefaultOAuth2UserService{

	private final MemberRepository memberRepository;
	private final PasswordEncoder passwordEncoder;
	
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		OAuth2User oAuth2User= super.loadUser(userRequest);
		String  registrationId=userRequest.getClientRegistration().getRegistrationId();
		return saveSocialUser(oAuth2User,registrationId);
	}

	private OAuth2User saveSocialUser(OAuth2User oAuth2User, String registrationId) {
	
		String name=null;
		String email=null;
		String pass=registrationId;
		if(registrationId.equals("google")) {
			name=oAuth2User.getAttribute("name");
			email=oAuth2User.getAttribute("email");
		}else if(registrationId.equals("naver")) {
			Map<String, Object> response=oAuth2User.getAttribute("response");
			name=(String) response.get("name");
			email=(String) response.get("email");
		}else if(registrationId.equals("kakao")) {
			Map<String, Object> kakaoAccount=oAuth2User.getAttribute("kakao_account");
			email=(String) kakaoAccount.get("email");
			@SuppressWarnings("unchecked")
			Map<String, Object> profile=(Map<String, Object>) kakaoAccount.get("profile");
			//System.out.println(profile);
			name=(String)profile.get("nickname");
		}
		
		Optional<Member> result=memberRepository.findByEmailAndIsDeletedAndIsSocial(email,false,true);
		
		if(result.isPresent()) {
			Member entity=memberRepository.save(
					result.get().socialUpdate(name, passwordEncoder.encode(pass)));
			return new CustomUserDetails(entity);
		}
		
		Member entity=memberRepository.save(Member.builder()
				.email(email).name(name).pass(passwordEncoder.encode(pass))
				.userIp("127.0.0.1")
				.isSocial(true)
				.build().addRole(MemberRole.USER));
		
		return new CustomUserDetails(entity);
	}
}
