package com.cho.dessert.security;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Configuration
public class SecurityConfig {
	
	private final CustomOauth2UserService customOauth2UserService;
	private final CustomUserDetailsService customUserDetailsService;
	private final DataSource dataSource;
	
	
	@Bean
	public PersistentTokenRepository persistentTokenRepository() {
		JdbcTokenRepositoryImpl repo = new JdbcTokenRepositoryImpl();
		repo.setDataSource(dataSource);
		return repo;
	}
		
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
			.authorizeRequests(authorize -> 
			authorize
				.antMatchers("/","/common/**","/request-key/*","/summernote/**").permitAll()
				.antMatchers("/admin/**").hasRole("ADMIN")
				.antMatchers("/board/**").hasRole("USER")
				.anyRequest().authenticated()
			);
		
		///로그인페이지 설정
		http.formLogin(formLogin ->
			formLogin
				.loginPage("/login")//get 로그인페이지이동 url
				.usernameParameter("email")
				.passwordParameter("pass")
				.failureUrl("/login?error")
				.loginProcessingUrl("/login")//form action post Security가 처리해주는 url -> UserdetailsService
				.defaultSuccessUrl("/", true)
				//.successHandler(null)
				//.failureHandler(null)
				.permitAll()
		);
		
		http.oauth2Login(oauth2Login->
			oauth2Login
				.loginPage("/login")
				.userInfoEndpoint()
				.userService(customOauth2UserService));
		
		http.logout(logout -> logout
        		.logoutSuccessUrl("/")
        		.invalidateHttpSession(true)
        		.deleteCookies("remember-me","JSESSIONID")
        		);
		
		http.rememberMe(remember->
				remember
					.key("uniqueAndSecret")
					.rememberMeParameter("remember-me")
					.tokenRepository(persistentTokenRepository())
					.tokenValiditySeconds(86400*30)
					);
		http.csrf();
			
		return http.build();
	}
	
	
	@Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().antMatchers(
        		"/css/**"
        		,"/js/**"
        		,"/images/**"
        		,"/favicon.ico*"
        );
    }
	
	
	
}
