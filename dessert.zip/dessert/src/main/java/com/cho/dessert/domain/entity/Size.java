package com.cho.dessert.domain.entity;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Size {

	S("소"),M("중"),L("대");
	
	private final String korSizes;
}
