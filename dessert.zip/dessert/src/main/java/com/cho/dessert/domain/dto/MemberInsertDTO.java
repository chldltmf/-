package com.cho.dessert.domain.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.security.crypto.password.PasswordEncoder;

import com.cho.dessert.domain.entity.Member;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MemberInsertDTO {
	
	
	private String email;
	private String name;
	@NotBlank(message = "비밀번호는 필수 입력 값입니다.")
	@Pattern(regexp = "(?=.*[0-9])(?=.*[a-zA-Z])(?=.*\\W)(?=\\S+$).{8,16}", message = "비밀번호는 8~16자 영문 대 소문자, 숫자, 특수문자를 사용하세요.")
	private String pass;
	private String userIp;
	
	public MemberInsertDTO passEncode(PasswordEncoder pe) {
		this.pass=pe.encode(pass);
		return this;
	}
	
	//입력받은 dto-> Member 엔티티에 매핑: Member 객체생성
	public Member toMember() {
		return Member.builder()
				.email(email).name(name).pass(pass).userIp(userIp)
				.build();
	}
}
