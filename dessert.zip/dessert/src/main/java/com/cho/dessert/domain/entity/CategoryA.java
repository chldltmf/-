package com.cho.dessert.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CategoryA {

	INGREDIENTS("홈베이킹재료",1100,"ingredients"),
	TOOLS("홈베이킹도구",1200,"tools"),
	COOKIE("쿠키",1300,"cookie"),
	BREAD("빵류",1400,"bread"),
	CAKE("케이크",1500,"cake"),
	CHOCOLATE("초콜렛",1600,"chocolate"),
	ETC("기타",1700,"etc");
	
	final String koName;
	final long code;
	final String lower;
}
