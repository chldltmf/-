package com.cho.dessert.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.visual.VisualInsertDTO;
import com.cho.dessert.service.VisualService;

@Controller
public class VisualController {

	@Autowired
	private VisualService visualService;
	
	//index의 visual : ajax페이지
	@GetMapping("/common/visuals")
	public String indexList(Model model) {
		return visualService.indexList(model);
	}
	
	//등록페이지 이동
	@GetMapping("/admin/visuals/write")
	public String write() {
		return "/admin/visual/write";
	}
	
	//등록된 이미지 목록
	@GetMapping("/admin/visuals")
	public String list(Model model) {
		return visualService.list(model);
	}
	//등록
	@PostMapping("/admin/visuals")
	public String save(MultipartFile vimg, VisualInsertDTO dto) {
		return visualService.save(vimg, dto);
	}
}
