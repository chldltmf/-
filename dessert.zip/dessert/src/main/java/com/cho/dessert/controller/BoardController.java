package com.cho.dessert.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.board.BoardInsertDTO;
import com.cho.dessert.domain.dto.board.BoardUpdateDTO;
import com.cho.dessert.service.BoardService;

@Controller
public class BoardController {

	@Autowired
	private BoardService boardService;
	
	//인덱스페이시->게시글이동->게시글 목록가져오기
	@GetMapping("/common/boards")
	public String list(Model model,@RequestParam(defaultValue = "1") int pageNo) {
		
		boardService.list(model,pageNo);
		
		return "board/list";
	}
	
	//글쓰기페이지 이동
	@GetMapping("/board/write")
	public String write() {
		return "board/write";
	}
	
	//파일이 아직 서버
	@ResponseBody
	@PostMapping("/board/fileupload")
	public String fileUpload(MultipartFile file,String prevImgName) {
		return boardService.fileUpload(file,prevImgName);
	}
	
	//글쓰기 등록버튼 클릭 -> db에 저장
	@PostMapping("/board/write")
	public String wirte(MultipartFile file,BoardInsertDTO dto) {
		boardService.save(file,dto);
		return "redirect:/common/boards";
	}
	
	//글쓰기 상세페이지 이동
	@GetMapping("/board/{no}")
	public String detail(@PathVariable long no,Model model) {
		boardService.detail(no,model);
		return "board/detail";
	}
	
	//게시글 상세페이지 수정
	@PutMapping("/board/{no}")
	public String update(@PathVariable long no,BoardUpdateDTO dto) {
		boardService.update(no,dto);
		return "redirect:/board/"+no;
	}
	
	//게시글 상세페이지 삭제
	@ResponseBody
	@DeleteMapping("/board/{no}")
	public void delete(@PathVariable long no) {
		boardService.delete(no);
	}
}
