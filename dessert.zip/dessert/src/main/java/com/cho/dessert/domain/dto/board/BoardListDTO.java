package com.cho.dessert.domain.dto.board;

import java.time.LocalDateTime;

import com.cho.dessert.domain.entity.BoardEntity;

import lombok.Getter;

@Getter
public class BoardListDTO {
	
	private long no;
	private String title;
	private String writer;
	private LocalDateTime updatedDate;
	
	
	public BoardListDTO(BoardEntity b) {
		this.no =b.getNo();
		this.title = b.getTitle();
		this.updatedDate = b.getUpdatedDate();
		this.writer=b.getMember().getEmail();
	}
	
	
}
