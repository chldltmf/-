package com.cho.dessert.service.impl;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.FileData;
import com.cho.dessert.domain.dto.visual.VisualInsertDTO;
import com.cho.dessert.domain.dto.visual.VisualListDto;
import com.cho.dessert.domain.entity.VisualFileRepository;
import com.cho.dessert.service.VisualService;
import com.cho.dessert.utils.MyFileUtils;

@Service
public class VisualServiceProc implements VisualService {

	@Autowired
	private VisualFileRepository visualFileRepository;
	
	@Override
	public String save(MultipartFile vimg, VisualInsertDTO dto) {
		//파일업로드
		String url="/images/visual/";
		FileData fileDate=MyFileUtils.upload(vimg, url);
		dto.addFileDate(fileDate);
		
		//db저장
		visualFileRepository.save(dto.toVisualFile());
		return "redirect:/admin/visuals";
	}
	
	@Override
	public String list(Model model) {
		model.addAttribute("list",visualFileRepository.findAll()
					.stream().map(VisualListDto::new).collect(Collectors.toList()));
		return "/admin/visual/list";
	}

	//index의 ajax처리
	@Override
	public String indexList(Model model) {
		model.addAttribute("list",visualFileRepository.findAllByIsShowOrderByNum(true)
				.stream().map(VisualListDto::new).collect(Collectors.toList()));
		return "/visual/list";
	}

}
