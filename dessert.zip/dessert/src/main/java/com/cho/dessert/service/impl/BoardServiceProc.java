package com.cho.dessert.service.impl;

import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.board.BoardDetailDTO;
import com.cho.dessert.domain.dto.board.BoardInsertDTO;
import com.cho.dessert.domain.dto.board.BoardListDTO;
import com.cho.dessert.domain.dto.board.BoardUpdateDTO;
import com.cho.dessert.domain.entity.BoardEntity;
import com.cho.dessert.domain.entity.BoardEntityRepository;
import com.cho.dessert.domain.entity.BoardFileEntity;
import com.cho.dessert.domain.entity.Member;
import com.cho.dessert.domain.entity.MemberRepository;
import com.cho.dessert.service.BoardService;
import com.cho.dessert.utils.PageInfo;

@Service
public class BoardServiceProc implements BoardService {

	@Autowired
	private BoardEntityRepository boardRepository;
	
	//인덱스페이시->게시글이동->게시글 목록가져오기
	@Override
	public void list(Model model,int pageNo) {
		int page=pageNo-1;
		int size=10;
		Sort sort=Sort.by(Direction.DESC,"no");
		Pageable pageable=PageRequest.of(page, size,sort);
		
		Page<BoardEntity> pageObj=boardRepository.findAll(pageable);
		int pageTotal=pageObj.getTotalPages();
		
		PageInfo pageInfo=PageInfo.getInstance(pageNo, pageTotal);
		model.addAttribute("pi",pageInfo);
		model.addAttribute("list",pageObj.getContent().stream()
				.map(BoardListDTO::new)
				.toList());
		
	}

	@Autowired
	private MemberRepository memberRepository;
	//글쓰기 등록버튼 클릭 -> db에 저장
	@Override
	public void save(MultipartFile file, BoardInsertDTO dto) {
		//memberRepository.findByEmail(dto.getEmail()).orElseThrow();
		BoardEntity entity=dto.toEntity(memberRepository.findByEmail(dto.getEmail()).orElseThrow());
			if(!file.isEmpty()) {
				String url="/images/qa/";
				
				ClassPathResource cprTemp=new ClassPathResource("static"+url+"temp");

				try {
					File root = cprTemp.getFile();
					File newFile=new File(root, dto.getNewName());
					
					ClassPathResource uploadDir=new ClassPathResource("static"+url);
					File dest=new File(uploadDir.getFile(),dto.getNewName());
					newFile.renameTo(dest);
					
					entity.addFile(BoardFileEntity.builder()
							.url(url)
							.size(file.getSize())
							.orgName(file.getOriginalFilename())
							.newName(dto.getNewName())
							.build());
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			}
			System.out.println(entity.toString());
			boardRepository.save(entity);
	}

	//글쓰기 상세페이지 이동
	@Override
	public void detail(long no, Model model) {
		model.addAttribute("detail", boardRepository.findById(no).map(BoardDetailDTO::new).get());
		
	}

	//파일이 아직 서버
	@Override
	public String fileUpload(MultipartFile file, String prevImgName) {
		
		String url="/images/qa/temp/";
		String orgName=file.getOriginalFilename();
		UUID uuid=UUID.randomUUID();
		String newName=uuid.toString()+"_"+orgName;
		ClassPathResource cpr=new ClassPathResource("static"+url);
		
		try {
			File root=cpr.getFile();
			File prevImg=new File(root,newName);
			if(prevImg.isFile())prevImg.delete();
			
			file.transferTo(new File(root,newName));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return newName;
	}

	//게시글 상세페이지 수정
	@Transactional
	@Override
	public void update(long no, BoardUpdateDTO dto) {
		boardRepository.findById(no).map(e->e.update(dto));
		
	}

	//게시글 상세페이지 삭제
	@Override
	public void delete(long no) {
		boardRepository.deleteById(no);
	}
}
