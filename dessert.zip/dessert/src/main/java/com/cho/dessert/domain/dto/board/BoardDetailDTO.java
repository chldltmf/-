package com.cho.dessert.domain.dto.board;

import java.time.LocalDateTime;
import java.util.List;

import com.cho.dessert.domain.entity.BoardEntity;
import com.cho.dessert.domain.entity.Member;

import lombok.Getter;

@Getter
public class BoardDetailDTO {

	private long no;
	private String title;
	private String content;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	private String email;
	
	private List<FileDTO> files;
	
	public BoardDetailDTO(BoardEntity b) {
		this.no = b.getNo();
		this.title = b.getTitle();
		this.content = b.getContent();
		this.createdDate = b.getCreatedDate();
		this.updatedDate = b.getUpdatedDate();
		this.email=b.getMember().getEmail();
		files=b.getFiles().stream()
				.map(FileDTO::new)
				.toList();
	}
	
	
}
