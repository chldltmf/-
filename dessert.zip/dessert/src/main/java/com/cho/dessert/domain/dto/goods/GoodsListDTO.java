package com.cho.dessert.domain.dto.goods;

import com.cho.dessert.domain.entity.Goods;

import lombok.Getter;

@Getter
public class GoodsListDTO {

	private long gno;
	private String name;
	private int price;
	private int sale;
	private int stock;

	private String defImgUrl;
	
	public GoodsListDTO(Goods e) {
		gno=e.getGno();
		name=e.getName();
		price=e.getPrice();
		sale=e.getSale();
		stock=e.getStock();
		
		e.getFiles()
		.forEach(fe->{if(fe.isDefImg())defImgUrl=fe.getUrl()+fe.getOrgName();
		});
	}
}
