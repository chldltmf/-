package com.cho.dessert.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.goods.GoodsInsertDTO;
import com.cho.dessert.domain.entity.CategoryA;
import com.cho.dessert.service.GoodsService;

@Controller
public class GoodsController {

	@Autowired
	private GoodsService goodsService;
	
	//상품등록페이지 이동
	@GetMapping("/admin/goods/write")
	public String goods(Model model) {
		model.addAttribute("cateA",CategoryA.values());
		for(CategoryA cate:CategoryA.values()) {
			System.out.println(cate.getKoName());
		}
		return "admin/goods/write";
	}
	
	//파일업로드
	@ResponseBody
	@PostMapping("/admin/goods/fileupload")
	public String tempFileupload(MultipartFile file) {
		return goodsService.tempFileupload(file);
	}
	
	//ajax를 통한 2차카테고리 목록가져오기
	@GetMapping("/admin/category/{caNo}")
	public String category(@PathVariable long caNo,Model model) {
		model.addAttribute("option",goodsService.categoryList(caNo));
		return "admin/goods/category-data";
	}

	//상품등록
	@PostMapping("/admin/goods")
	public String goods(GoodsInsertDTO dto) {
		return goodsService.save(dto);
	}
	
	//관리자페이지 -> 상품리스트페이지이동
	@GetMapping("/admin/goods")
	public String list(Model model) {
		return goodsService.list(model);
	}
	
	//ajax index페이지 상품리스트
	@GetMapping("/common/goods")
	public String indexList(Model model) {
		return goodsService.indexList(model);
	}
	
	//상품상세페이지
	@GetMapping("/common/goods/{gno}")
	public String detail(@PathVariable long gno,Model model) {
		return goodsService.detail(gno,model);
	}
	
	//카테고리 상위목록이동
	@GetMapping("/common/category-a/{caNo}/goods")
	public String goodsListByCategoryA(@PathVariable long caNo,Model model) {
		goodsService.goodsListByCategoryA(caNo,model);
		return "goods/list";
	}
	
	//카테고리 하위목록이동
	@GetMapping("/common/categorys/{caNo}/goods")
	public String goodsListByCategory(@PathVariable long caNo,Model model) {
		goodsService.goodsListByCaNo(caNo,model);
		return "goods/list";
	}
}
