package com.cho.dessert.service;

import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.goods.CategoryDTO;
import com.cho.dessert.domain.dto.goods.GoodsInsertDTO;

public interface GoodsService {

	String tempFileupload(MultipartFile file);

	String save(GoodsInsertDTO dto);
	
	String list(Model model);

	List<CategoryDTO> categoryList(long caNo);

	String indexList(Model model);

	String detail(long gno, Model model);

	void goodsListByCategoryA(long caNo, Model model);

	void goodsListByCaNo(long caNo, Model model);

	
	

}
