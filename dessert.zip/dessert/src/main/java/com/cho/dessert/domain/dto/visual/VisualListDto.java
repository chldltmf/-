package com.cho.dessert.domain.dto.visual;

import com.cho.dessert.domain.entity.VisualFile;

import lombok.Getter;

@Getter
public class VisualListDto {

	private long vno;
	private String url;
	private String orgName;
	private long size;
	private String title;
	private String sub;
	private long num;
	private boolean isShow;
	private String link;
	
	public VisualListDto(VisualFile e) {
		this.vno = e.getVno();
		this.url = e.getUrl();
		this.orgName = e.getOrgName();
		this.size = e.getSize();
		this.title = e.getTitle();
		this.sub = e.getSub();
		this.num=e.getNum();
		this.isShow=e.isShow();
		this.link=e.getLink();
	}
	
	
}
