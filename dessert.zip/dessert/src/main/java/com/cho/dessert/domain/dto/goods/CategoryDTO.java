package com.cho.dessert.domain.dto.goods;

import com.cho.dessert.domain.entity.Category;

import lombok.Getter;

@Getter
public class CategoryDTO {

	private long caNo;
	private String name;
	private long code;
	
	public CategoryDTO(Category e) {
		caNo=e.getCaNo();
		name=e.getName();
		code=e.getCode();
	}
}
