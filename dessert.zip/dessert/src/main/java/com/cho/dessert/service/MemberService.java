package com.cho.dessert.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.validation.Errors;

import com.cho.dessert.domain.dto.MemberInsertDTO;

public interface MemberService {

	String save(MemberInsertDTO dto, HttpServletRequest request);

	Map<String, String> validateHandling(Errors errors);


}
