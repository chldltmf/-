package com.cho.dessert.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BoardFileEntityRepository extends JpaRepository<BoardFileEntity, Long>{

}
