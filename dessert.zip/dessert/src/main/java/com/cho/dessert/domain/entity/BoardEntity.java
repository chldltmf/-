package com.cho.dessert.domain.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.cho.dessert.domain.dto.board.BoardUpdateDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;


@Builder
@AllArgsConstructor
@DynamicUpdate
@NoArgsConstructor//No default constructor for entity: db에서 결과를 매핑을 위해서 필요합니다.
@Getter
@EntityListeners(AuditingEntityListener.class)
@Entity
public class BoardEntity extends BaseTimeEntity{//jpa_board_entity
	

	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto_increment
	@Id
	private long no;
	
	@Column(nullable = false)//not null
	private String title;
	@Column(columnDefinition = "text not null") //text : oracle-CLOB
	private String content;
	
	@JoinColumn(name = "memberNo" )
	@ManyToOne
	private Member member;
	
	@Builder.Default
	@JoinColumn(name="boardFileNo")
	@OneToMany(cascade = CascadeType.ALL)
	private List<BoardFileEntity> files=new ArrayList<>();
	
	//파일추가
	public BoardEntity addFile(BoardFileEntity file) {
		files.add(file);
		return this;
	}

	//게시글 상세페이지 수정
	public BoardEntity update(BoardUpdateDTO dto) {
		this.title=dto.getTitle();
		this.content=dto.getContent();
		return this;
	}
	

}
