package com.cho.dessert.service;

public interface MailService {
	
	public long mailSend(String email);
	
	//public String mailCheck(MailRequestDto dto);

}
