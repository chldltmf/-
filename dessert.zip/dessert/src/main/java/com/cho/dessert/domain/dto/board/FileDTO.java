package com.cho.dessert.domain.dto.board;

import com.cho.dessert.domain.entity.BoardFileEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class FileDTO {
	
	private long fno;
	private String url;
	private String orgName;
	private String newName;
	private long size;
	
	public FileDTO(BoardFileEntity f) {
		this.fno=f.getFno();
		this.url=f.getUrl();
		this.orgName=f.getOrgName();
		this.newName=f.getNewName();
		this.size=f.getSize();
	}

}
