package com.cho.dessert.domain.entity;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Color {

	BLACK("검정"),WHITE("흰색");
	
	private final String korColor;
}
