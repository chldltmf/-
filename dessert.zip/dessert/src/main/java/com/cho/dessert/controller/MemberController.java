package com.cho.dessert.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cho.dessert.domain.dto.MemberInsertDTO;
import com.cho.dessert.service.MailService;
import com.cho.dessert.service.MemberService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
public class MemberController {
	
	
	private final MemberService service;
	private final MailService mailService;
	
	//회원가입+정규화표현
	@PostMapping("/common/signup")
	public String signup(@Valid MemberInsertDTO dto,Errors errors, HttpServletRequest request,Model model) {
		if (errors.hasErrors()) {
			model.addAttribute("userDto", dto);
			 Map<String, String> validatorResult=service.validateHandling(errors);
			 for (String key : validatorResult.keySet()) {                
				 model.addAttribute(key, validatorResult.get(key));            
			 }
			 return "sign/signup"; 
		}
		return service.save(dto, request);
	}
	
	//인증번호발송
	@ResponseBody
	@PostMapping("/request-key/mail")
	public long requestMailKey(String email) {
		//System.out.println(email);
		return mailService.mailSend(email);
	}	
	
	//인증번호입력
	@ResponseBody
	@GetMapping("/request-key/getKey")
	public String requestgetKey(HttpSession session) {
		//System.out.println(email);
		return (String) session.getAttribute("mailKey");
	}

}
