package com.cho.dessert.domain.dto.goods;

import com.cho.dessert.domain.entity.Goods;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
public class GoodsInsertDTO {

	private String name;
	private int price;
	private int sale;
	private boolean isRate;//false:원 ,true:%
	private int stock;
	private String defImgName;
	private String addImgName;
	private String content;
	
	private long caNo;

	public Goods toEntity() {
		if(isRate) {
			sale=price*sale/100;
		}
		return Goods.builder()
				.name(name).price(price).sale(sale).stock(stock).content(content)
				.build();
	}
}
