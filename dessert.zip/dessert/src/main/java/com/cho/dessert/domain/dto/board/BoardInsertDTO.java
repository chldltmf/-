package com.cho.dessert.domain.dto.board;

import com.cho.dessert.domain.entity.BoardEntity;
import com.cho.dessert.domain.entity.Member;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardInsertDTO {

	private String title;
	private String content;
	private String newName;
	private String email;
	
	
	
	public BoardEntity toEntity(Member member) {
		return BoardEntity.builder()
				.title(title).content(content).member(member)
				.build();
	}
	
}
