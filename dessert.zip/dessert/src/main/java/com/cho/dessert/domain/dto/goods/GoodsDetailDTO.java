package com.cho.dessert.domain.dto.goods;

import java.util.List;

import com.cho.dessert.domain.entity.Goods;

import lombok.Getter;

@Getter
public class GoodsDetailDTO {

	private long gno;
	private String name;
	private int price;//판매가
	private int sale;//할인
	private int stock;
	private String content;
	
	private List<GoodsFileDTO> files;
	
	public GoodsDetailDTO(Goods g) {
		this.gno = g.getGno();
		this.name = g.getName();
		this.price = g.getPrice();
		this.sale = g.getSale();
		this.stock = g.getStock();
		this.content = g.getContent();
		
		files=g.getFiles().stream()
				.map(GoodsFileDTO::new)
				.toList();
	}
	
	
}
