package com.cho.dessert.domain.entity;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Entity
public class Category {

	@Id
	private long caNo;
	
	private String name;
	private long code;
	
	@Enumerated(EnumType.STRING)
	private CategoryA cateA;//상위카테고리
	
	@Builder.Default
	@ManyToMany(mappedBy = "categorys")
	private Set<Goods> goods=new HashSet<>();
	
	public Category createNo() {
		caNo=cateA.code+code;
		return this;
	}
}
