package com.cho.dessert.domain.dto.board;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BoardUpdateDTO {

	private String title;
	private String content;
}
