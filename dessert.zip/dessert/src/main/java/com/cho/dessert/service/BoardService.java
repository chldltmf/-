package com.cho.dessert.service;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.cho.dessert.domain.dto.board.BoardInsertDTO;
import com.cho.dessert.domain.dto.board.BoardUpdateDTO;

public interface BoardService {

	void list(Model model,int pageNo);

	void save(MultipartFile file, BoardInsertDTO dto);

	void detail(long no, Model model);

	String fileUpload(MultipartFile file, String prevImgName);

	void update(long no, BoardUpdateDTO dto);

	void delete(long no);


}
