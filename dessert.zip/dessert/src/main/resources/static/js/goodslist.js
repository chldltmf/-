/**
 * 
 */
 
 $(function(){
	$.get("/common/goods",function(listHTMLData){
		$("#goods-list>.wrap").html(listHTMLData);
	});
});