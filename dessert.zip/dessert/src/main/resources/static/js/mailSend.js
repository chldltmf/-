/**
 * 
 */
var createDate;
$(function(){
		$("#key").hide();
		$("#btn-mail").click(function(){
			var token = $("meta[name='_csrf']").attr("content");
			var header = $("meta[name='_csrf_header']").attr("content");
			$.ajax({
				beforeSend: function(xhr){xhr.setRequestHeader(header, token);},
				url:"/request-key/mail",
				type: "post",
				data: {email:$("#in-mail").val()},
				success:function(result){
					
					$("#key").show();
					
					
				}
			});
		});
		
		$("#key").blur(function(){
			//console.log("입력한 코드"+$(this).val());
			var inputKey=$(this).val();
			$.get("/request-key/getKey",function(scode){
				
				if(scode==inputKey){
					$(".mail-msg").text("인증성공").css("color","green");
				}else{
					$(".mail-msg").text("인증실패").css("color","red");
				}
			});
		});
	});

